TO ACCESS GAME:
- Run DoggoDashAlpha.exe
- Play at 1920x1080 for best results!

TO LOAD GAME LEVEL:
- Press Start Button to access the first level


CONTROLS:
- WASD to move
- Left click to shoot treats

HOW-TO PLAY:
- Attract dogs by shooting treats at them to get them to follow you.
- Avoid dognappers who will try to steal your dogs!
- Survive the timer and try to save as many dogs as possible!